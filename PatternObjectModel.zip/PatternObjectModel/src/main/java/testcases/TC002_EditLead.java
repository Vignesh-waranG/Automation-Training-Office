package testcases;

import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import pages.FindLeadPage;
import pages.HomePage;
import pages.LeadsPage;
import pages.LoginPage;
import pages.MyHomePage;
import wdMethods.ProjectMethods;

public class TC002_EditLead extends ProjectMethods{
	@BeforeTest
	public void setData() {
		testCaseName = "TC002_EditLeads";
		testDescription = "Edit Leads";
		fileName = "TC002";
		browserName = "chrome";
		category = "smoke";
		authors = "Vignesh";
		testNodes = "Leads";
	}

	@Test(dataProvider="fetchData")
	public void login(String uName,String pwd, String Name, String Title) {
		new LoginPage()
		.typeUserName(uName)
		.typePassword(pwd)
		.clickLogin();
		/*.clickLogOut()*/

		new HomePage()
		.clickCRMLink();
		
		new MyHomePage()
		.clickLeads();
		
		new LeadsPage()
		.clickFindLeads();

		new FindLeadPage()
		.typeLeadName(Name)
		.ClickFindLead()
		.ClickFirstName()
		.ClickEditRecord()
		.typeTitledata(Title)
		.ClickUpdate();

	}




}
