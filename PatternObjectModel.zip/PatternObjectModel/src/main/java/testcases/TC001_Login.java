package testcases;

import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import pages.LoginPage;
import wdMethods.ProjectMethods;

public class TC001_Login extends ProjectMethods{
	@BeforeTest
	public void setData() {
		testCaseName = "TC001_Login";
		testDescription = "Login to LeafTaps";
		fileName = "TC001";
		browserName = "chrome";
		category = "smoke";
		authors = "sarath";
		testNodes = "Leads";
	}
	
	@Test(dataProvider="fetchData")
	public void login(String uName,String pwd) {
		 new LoginPage()
		.typeUserName(uName)
		.typePassword(pwd)
		.clickLogin()
		.clickLogOut();
	}
	
}
