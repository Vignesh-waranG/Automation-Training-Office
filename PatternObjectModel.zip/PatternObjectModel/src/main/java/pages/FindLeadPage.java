package pages;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import wdMethods.ProjectMethods;

public class FindLeadPage  extends ProjectMethods{

	public FindLeadPage() {
		PageFactory.initElements(driver, this);
	}


	@FindBy(xpath = "(//input[@name='firstName'])[3]")
	private WebElement TypeLeadname;
	public FindLeadPage typeLeadName(String data) {
		type(TypeLeadname, data);
		return this;
	}
	
	@FindBy(xpath = "//button[contains(text(),'Find Leads')]")
	private WebElement ClickFindLead;
	public FindLeadPage ClickFindLead() {
		click(ClickFindLead);
		return this;
	}
	
	@FindBy(xpath = "(//div[@class='x-grid3-cell-inner x-grid3-col-partyId'])[1]/a")
	private WebElement ClickName;
	public FindLeadPage ClickFirstName() {
		click(ClickName);
		return this;
	}
	
	@FindBy(xpath = "//a[contains(text(),'Edit')]")
	private WebElement EditRecord;
	public FindLeadPage ClickEditRecord() {
		click(EditRecord);
		return this;
	}
	
	@FindBy(id = "updateLeadForm_generalProfTitle")
	private WebElement Edittitle;
	public FindLeadPage typeTitledata(String data) {
		type(Edittitle, data);
		return this;
	}
	
	@FindBy(xpath = "//input[@class='smallSubmit']")
	private WebElement ClickUpdate;
	public FindLeadPage ClickUpdate() {
		click(ClickUpdate);
		return this;
	}
	
}


