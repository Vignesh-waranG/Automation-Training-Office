package pages;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import wdMethods.ProjectMethods;

public class HomePage  extends ProjectMethods{

	public HomePage() {
		PageFactory.initElements(driver, this);
	}
	/*
	@FindBy(className = "decorativeSubmit")
	private WebElement eleLogout;
	public MyHomePage clickLogOut() {
		click(eleLogout);
		return new MyHomePage();
	}*/
	@FindBy(linkText = "CRM/SFA")
	private WebElement clickLink;
	public MyHomePage clickCRMLink() {
		click(clickLink);
		return new MyHomePage();
	}
	
}
