package pages;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import wdMethods.ProjectMethods;

public class MyHomePage  extends ProjectMethods{

	public MyHomePage() {
		PageFactory.initElements(driver, this);
	}
	/*
	@FindBy(className = "decorativeSubmit")
	private WebElement eleLogout;
	public MyHomePage clickLogOut() {
		click(eleLogout);
		return new MyHomePage();
	}*/
	@FindBy(linkText = "Leads")
	private WebElement clickLeads;
	public LeadsPage clickLeads() {
		click(clickLeads);
		return new LeadsPage();
	}
	
}
