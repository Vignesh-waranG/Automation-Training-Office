package pages;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import wdMethods.ProjectMethods;

public class CreateLead  extends ProjectMethods{

	public CreateLead() {
		PageFactory.initElements(driver, this);
	}

	@FindBy(id = "createLeadForm_companyName")
	private WebElement CompanyName;
	public CreateLead typeCompanyName(String data) {
		type(CompanyName, data);
		return this;
	}

	@FindBy(id = "createLeadForm_firstName")
	private WebElement FName;
	public CreateLead typeFirstName(String data) {
		type(FName, data);
		return this;
	}

	@FindBy(id = "createLeadForm_lastName")
	private WebElement LName;
	public CreateLead typeLastName(String data) {
		type(LName, data);
		return this;
	}

	@FindBy(id = "createLeadForm_primaryEmail")
	private WebElement Email;
	public CreateLead typeEmail(String data) {
		type(Email, data);
		return this;
	}

	@FindBy(id = "createLeadForm_primaryPhoneNumber")
	private WebElement PNumber;
	public CreateLead typePhnumber(String data) {
		type(PNumber, data);
		return this;
	}
	
	@FindBy(name = "submitButton")
	private WebElement CSubmit;
	public FindLeadPage clickCreateSubmit() {
		click(CSubmit);
		return new FindLeadPage();
	}
}

