package pages;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import wdMethods.ProjectMethods;

public class LoginPage  extends ProjectMethods{

	public LoginPage() {
		PageFactory.initElements(driver, this);
	}

	@FindBy(id = "username")
	private WebElement eleUserName;

	public LoginPage typeUserName(String data) {
		//	WebElement eleUserName = locateElement("id", "username");
		type(eleUserName, data);
		return this;
	}

	@FindBy(id = "password")
	private WebElement elePassword;
	public LoginPage typePassword(String data) {
		type(elePassword, data);
		return this;
	}

	@FindBy(className = "decorativeSubmit")
	private WebElement eleLogin;
	public HomePage clickLogin() {
		click(eleLogin);
		return new HomePage();
	}



}
