package pages;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import wdMethods.ProjectMethods;

public class LeadsPage  extends ProjectMethods{

	public LeadsPage() {
		PageFactory.initElements(driver, this);
	}


	
	@FindBy(linkText = "My Leads")
	private WebElement clickMyLeads;
	public LeadsPage clickMyLeads() {
		click(clickMyLeads);
		return this;
	}

	@FindBy(linkText = "Create Lead")
	private WebElement clickCreateLeads;
	public CreateLead clickCreateLeads() {
		click(clickCreateLeads);
		return new CreateLead();
	}

	@FindBy(linkText = "Find Leads")
	private WebElement clickFindLeads;
	public FindLeadPage clickFindLeads() {
		click(clickFindLeads);
		return new FindLeadPage();
	}

	@FindBy(linkText = "Merge Leads")
	private WebElement clickMergeLeads;
	public LeadsPage clickMergeLeads() {
		click(clickMergeLeads);
		return this;
	}

}


